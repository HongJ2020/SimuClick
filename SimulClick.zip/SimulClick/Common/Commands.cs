﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Common
{
    /// <summary>
    /// Contains extensions methods for <see cref="ICommand"/>.
    /// </summary>
    public static class CommandExtensions
    {
        /// <summary>
        /// Raises a <c>CanExecuteChanged</c> event on a command.
        /// </summary>
        /// <param name="command">The command to raise the event.</param>
        public static void RaiseCanExecuteChanged(this ICommand command)
        {
            var canExecuteChanged = command as IRaiseCanExecuteChanged;
            canExecuteChanged?.RaiseCanExecuteChanged();
        }
    }

    /// <summary>
    /// Defines a method for raising a <c>CanExecuteChanged</c> event.
    /// </summary>
    public interface IRaiseCanExecuteChanged
    {
        /// <summary>
        /// Raises a <c>CanExecuteChanged</c> event.
        /// </summary>
        void RaiseCanExecuteChanged();
    }

    /// <summary>
    /// Defines an asynchronous command with a command parameter of type <see cref="object"/>.
    /// </summary>
    public interface IAsyncCommand : IAsyncCommand<object>
    {
    }

    /// <summary>
    /// Defines an generic asynchronous command with a command parameter.
    /// </summary>
    /// <typeparam name="T">The type of the command parameter.</typeparam>
    public interface IAsyncCommand<in T> : IRaiseCanExecuteChanged
    {
        /// <summary>
        /// Asynchronously executes the command with the specified command parameter.
        /// </summary>
        /// <param name="obj">The command parameter.</param>
        /// <returns></returns>
        Task ExecuteAsync(T obj);

        /// <summary>
        /// Returns a value indicating whether the command can be executed.
        /// </summary>
        /// <param name="obj">The command parameter.</param>
        /// <returns><c>true</c> if the command can be executed, <c>false</c> otherwise.</returns>
        bool CanExecute(object obj);

        /// <summary>
        /// Gets or sets the synchronous command wrapped in this asynchronous wrapper.
        /// </summary>
        ICommand Command { get; }
    }

    /// <summary>
    /// Defines a concrete version of the <see cref="AwaitableDelegateCommand{T}"/> with command paramater of type <see cref="object"/>.
    /// </summary>
    public class AwaitableDelegateCommand : AwaitableDelegateCommand<object>, IAsyncCommand
    {
        /// <summary>
        /// Initializes an awaitable delegate command with the specified execution method.
        /// </summary>
        /// <param name="executeMethod">The command execution method.</param>
        /// <param name="trackerID">The command ID for analytics.</param>
        public AwaitableDelegateCommand(Func<Task> executeMethod, string trackerID = "")
            : base(o => executeMethod())
        {
        }

        /// <summary>
        /// Initializes an awaitable delegate command with the specified execution method and the method for determining whether the command can be executed.
        /// </summary>
        /// <param name="executeMethod">The command execution method.</param>
        /// <param name="canExecuteMethod">The method for determining whether the command can be executed.</param>
        /// <param name="trackerID">The command ID for analytics.</param>
        public AwaitableDelegateCommand(Func<Task> executeMethod, Func<bool> canExecuteMethod, string trackerID = "")
            : base(o => executeMethod(), o => canExecuteMethod())
        {
        }
    }

    /// <summary>
    /// A class that implements a generic asynchronous command.
    /// </summary>
    /// <typeparam name="T">The type of the command parameter.</typeparam>
    public class AwaitableDelegateCommand<T> : IAsyncCommand<T>, ICommand
    {
        private readonly Func<T, Task> _executeMethod;
        private readonly DelegateCommand<T> _underlyingCommand;
        private bool _isExecuting;

        /// <summary>
        /// Initializes an awaitable delegate command with the specified execution method.
        /// </summary>
        /// <param name="executeMethod">The command execution method.</param>
        public AwaitableDelegateCommand(Func<T, Task> executeMethod)
            : this(executeMethod, _ => true)
        {
        }

        /// <summary>
        /// Initializes an awaitable delegate command with the specified execution method and the method for determining whether the command can be executed.
        /// </summary>
        /// <param name="executeMethod">The command execution method.</param>
        /// <param name="canExecuteMethod">The method for determining whether the command can be executed.</param>
        public AwaitableDelegateCommand(Func<T, Task> executeMethod, Func<T, bool> canExecuteMethod)
        {
            _executeMethod = executeMethod;
            _underlyingCommand = new DelegateCommand<T>(x => { }, canExecuteMethod);
        }

        /// <summary>
        /// Asynchronously executes the command execution method.
        /// </summary>
        /// <param name="obj">The command parameter.</param>
        /// <returns>The awaitable task for executing the command.</returns>
        public async Task ExecuteAsync(T obj)
        {
            try
            {
                _isExecuting = true;
                RaiseCanExecuteChanged();
                await _executeMethod(obj);
            }
            finally
            {
                _isExecuting = false;
                RaiseCanExecuteChanged();
            }
        }

        /// <inheritdoc/>
        public ICommand Command { get { return this; } }

        /// <inheritdoc/>
        public bool CanExecute(object parameter)
        {
            return !_isExecuting && _underlyingCommand.CanExecute((T)parameter);
        }

        /// <inheritdoc/>
        public event EventHandler CanExecuteChanged
        {
            add { _underlyingCommand.CanExecuteChanged += value; }
            remove { _underlyingCommand.CanExecuteChanged -= value; }
        }

        /// <inheritdoc/>
        public async void Execute(object parameter)
        {
            await ExecuteAsync((T)parameter);
        }

        /// <inheritdoc/>
        public void RaiseCanExecuteChanged()
        {
            _underlyingCommand.RaiseCanExecuteChanged();
        }
    }

    /// <summary>
    /// A generic implementation of <see cref="ICommand"/> and <see cref="IRaiseCanExecuteChanged"/>.
    /// </summary>
    /// <typeparam name="T">The type of the command parameter.</typeparam>
    public class DelegateCommand<T> : ICommand, IRaiseCanExecuteChanged
    {
        private readonly Action<T> m_Execute;
        private readonly Func<T, bool> m_CanExecute;
        private bool m_IsExecuting;

        /// <summary>
        /// Initializes a new command with a specified method to be called when the command is invoked.
        /// </summary>
        /// <param name="execute">The method to be called when the command is invoked.</param>
        public DelegateCommand(Action<T> execute) : this(execute, null)
        {

        }

        /// <summary>
        /// Initializes a new command with a specified method to be called when the command is invoked 
        /// and a method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="execute">The method to be called when the command is invoked.</param>
        /// <param name="canExecute">The method that determines whether the command can execute in its current state.</param>
        public DelegateCommand(Action<T> execute, Func<T, bool> canExecute)
        {
            m_Execute = execute ?? throw new ArgumentNullException(nameof(execute));
            m_CanExecute = canExecute ?? (x => true);
        }

        /// <inheritdoc/>
        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        /// <inheritdoc/>
        bool ICommand.CanExecute(object parameter)
        {
            return !m_IsExecuting && m_CanExecute((T)parameter);
        }

        /// <inheritdoc/>
        void ICommand.Execute(object parameter)
        {
            m_IsExecuting = true;
            try
            {
                RaiseCanExecuteChanged();
                m_Execute((T)parameter);
            }
            finally
            {
                m_IsExecuting = false;
                RaiseCanExecuteChanged();
            }
        }

        /// <inheritdoc/>
        public bool CanExecute(T parameter)
        {
            if (m_CanExecute == null)
            {
                return true;
            }
            return m_CanExecute(parameter);
        }

        /// <inheritdoc/>
        public void Execute(T parameter)
        {
            m_Execute(parameter);
        }

        /// <summary>
        /// Updates state of the command.
        /// </summary>
        public void RaiseCanExecuteChanged()
        {
            CommandManager.InvalidateRequerySuggested();
        }
    }


    /// <summary>
    /// Implementation of <see cref="ICommand"/>.
    /// </summary>
    public class Command : ICommand
    {
        private readonly Action<object> m_Execute;
        private readonly Func<object, bool> m_CanExecute;

        /// <summary>
        /// Initializes a new command with a specified method to be called when the command is invoked.
        /// </summary>
        /// <param name="execute">The method to be called when the command is invoked.</param>
        public Command(Action<object> execute) : this(execute, null)
        {

        }

        /// <summary>
        /// Initializes a new command with a specified method to be called when the command is invoked 
        /// and a method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="execute">The method to be called when the command is invoked.</param>
        /// <param name="canExecute">The method that determines whether the command can execute in its current state.</param>
        public Command(Action<object> execute, Func<object, bool> canExecute)
        {
            m_Execute = execute ?? throw new ArgumentNullException(nameof(execute));
            m_CanExecute = canExecute ?? (x => true);
        }

        /// <inheritdoc/>
        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        /// <inheritdoc/>
        public bool CanExecute(object parameter)
        {
            return m_CanExecute(parameter);
        }

        /// <inheritdoc/>
        public void Execute(object parameter)
        {
            m_Execute(parameter);
        }

        /// <summary>
        /// Updates state of the command.
        /// </summary>
        public void Refresh()
        {
            CommandManager.InvalidateRequerySuggested();
        }
    }
}
