﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Common
{
    /// <summary>
    /// Base class implementing <see cref="INotifyPropertyChanged"/>.
    /// </summary>
    [Serializable]
    public class NotificationObject : INotifyPropertyChanged
    {
        /// <inheritdoc/>
        [field: XmlIgnore]
        [field: NonSerialized]
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Raises a <see cref="PropertyChanged"/> event for the specified property name.
        /// </summary>
        /// <param name="propertyName">The name of the property to notify.</param>
        protected void RaisePropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Removes all handlers for the <see cref="PropertyChanged"/> event.
        /// </summary>
        protected virtual void RemovePropertyChangedEventHandlers()
        {
            if (PropertyChanged != null)
            {
                foreach (Delegate d in PropertyChanged.GetInvocationList())
                {
                    PropertyChanged -= (PropertyChangedEventHandler)d;
                }
            }
        }

        /// <summary>
        /// Sets a new value to a field and raises a property change event.
        /// </summary>
        /// <typeparam name="T">Type of the field and the value.</typeparam>
        /// <param name="field">The field to which the new value is set.</param>
        /// <param name="value">The new value to set to the field.</param>
        /// <param name="propertyName">The name of the property whose setter called this method.</param>
        protected virtual void SetField<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return;

            field = value;
            RaisePropertyChanged(propertyName);
        }

        /// <summary>
        /// Sets a new value to a field and raises a property change event.
        /// </summary>
        /// <typeparam name="T">Type of the field and the value.</typeparam>
        /// <param name="field">The field to which the new value is set.</param>
        /// <param name="value">The new value to set to the field.</param>
        /// <param name="propertyNames">The names of the properties to raise property changed notification.</param>
        protected virtual void SetFieldMulti<T>(ref T field, T value, params string[] propertyNames)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return;

            field = value;
            if (propertyNames != null)
            {
                foreach (var propertyName in propertyNames)
                {
                    RaisePropertyChanged(propertyName);
                }
            }
        }
    }
}
