Choose a computer to act as the server, the other will be the client. The server and client need to be in the same network.
----- If you want to start Matlab then LabView in that order, then choose the LabView computer as the server.

A. On the server, open a command prompt as administrator
Run the following command:

netsh http add urlacl url=http://+:8733/ user=YOUR_WINDOWS_DEVICE_NAME

If successful, you will see this message: URL reservation successfully added

B. Also on the server, do the following:

1. Navigate to Control Panel, System and Security, and Windows Defender Firewall.
2. Select Advanced settings and highlight Inbound Rules in the left pane.
3. In the Actions panel (right) select New Rule.
4. Select Port, then Next
5. Enter into Specific local ports: 8733, then Next
6. Next
7. Next
8. Enter Name, e.g., "SimulClick TCP 8733", then Finish


C. Copy all files in the 'Debug' folder into Client computer, and same for Server computer

1.Run SimulClickServer.exe on the server, e.g., the LabView computer. Click 'Start' button.

2. SimulClickClient.exe.config on the client, replace 'localhost:8733' at line #18 with 'serverIPaddress:8733'.

3. Run SimulClickClient.exe on the client, e.g., the Matlab computer
 

Note:
What is the synchronization/click delay between two computers?
The program needs time (in ms) to complete the commands, and it also depends on the internet since two computers need to communicate with each other. It is <7ms, <9ms, <10ms, <15ms, <16ms, <24ms for some of my tests.

Task:
start LabVIEW at t1, start Matlab at t2 = t1 + dett(~5s), end Matlab at t3 = t2 + T(~60min), end LabVIEW at t4 = t3 + ~5s. record and save t1, t2,t3, t4

