﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimulClickClient.ViewModels
{
    /// <summary>
    /// View-model of the client interface.
    /// </summary>
    public class ClientViewModel: NotificationObject
    {
        private string m_ServerURI = Properties.Settings.Default.ServerURI;
        private string m_Messages = string.Empty;
        private SimulClickConfig m_StartConfig = new SimulClickConfig();
        private SimulClickConfig m_StopConfig = new SimulClickConfig();

        private MouseService.MouseServiceClient MouseService { get; set; } = new MouseService.MouseServiceClient();

        public string ServerURI
        {
            get => m_ServerURI;
            set => SetField(ref m_ServerURI, value);
        }

        public SimulClickConfig StartConfig
        {
            get => m_StartConfig;
            set => SetField(ref m_StartConfig, value);
        }

        public SimulClickConfig StopConfig
        {
            get => m_StopConfig;
            set => SetField(ref m_StopConfig, value);
        }

        public string Messages
        {
            get => m_Messages;
            set => SetField(ref m_Messages, value);
        }

        public ICommand StartCommand { get; private set; }

        public ICommand StopCommand { get; private set; }

        public ICommand SaveConfigCommand { get; private set; }

        public ICommand ConnectCommand { get; private set; }

        public ClientViewModel()
        {
            StartCommand = new Command(o => Start());
            StopCommand = new Command(o => Stop());
            SaveConfigCommand = new Command(o => SaveConfig());
            ConnectCommand = new Command(o => Connect());
            LoadConfig();
            Connect();
        }

        private void Start()
        {
            AddMessage("Clicking start buttons on both computer");
            SimulClick(StartConfig);
        }

        private void Stop()
        {
            AddMessage("Clicking stop buttons on both computer");
            SimulClick(StopConfig);
        }

        private void Connect()
        {
            try
            {
                AddMessage("Testing connection to the server");
                AddMessage($"Server URI: {MouseService.Endpoint.Address.Uri.AbsoluteUri}");
                bool result = MouseService.Connect();
                if (result)
                {
                    AddMessage("Server connection ok.");
                }
                else
                {
                    AddMessage("Something is wrong with the server connection.");
                }
            }
            catch (Exception ex)
            {
                AddException(ex);
                MouseService.Abort();
                MouseService = new MouseService.MouseServiceClient();
            }
        }

        private void LoadConfig()
        {
            try
            {
                AddMessage("Loading configuration");
                StartConfig.LocalButton.X = Properties.Settings.Default.LocalStartButtonX;
                StartConfig.LocalButton.Y = Properties.Settings.Default.LocalStartButtonY;
                StopConfig.LocalButton.X = Properties.Settings.Default.LocalStopButtonX;
                StopConfig.LocalButton.Y = Properties.Settings.Default.LocalStopButtonY;
                StartConfig.RemoteButton.X = Properties.Settings.Default.RemoteStartButtonX;
                StartConfig.RemoteButton.Y = Properties.Settings.Default.RemoteStartButtonY;
                StopConfig.RemoteButton.X = Properties.Settings.Default.RemoteStopButtonX;
                StopConfig.RemoteButton.Y = Properties.Settings.Default.RemoteStopButtonY;
                AddMessage("Configuration loaded!");
            }
            catch (Exception ex)
            {
                AddException(ex);
            }
        }

        private void SaveConfig()
        {
            try
            {
                AddMessage("Saving configuration");
                Properties.Settings.Default.LocalStartButtonX = StartConfig.LocalButton.X;
                Properties.Settings.Default.LocalStartButtonY = StartConfig.LocalButton.Y;
                Properties.Settings.Default.LocalStopButtonX = StopConfig.LocalButton.X;
                Properties.Settings.Default.LocalStopButtonY = StopConfig.LocalButton.Y;
                Properties.Settings.Default.RemoteStartButtonX = StartConfig.RemoteButton.X;
                Properties.Settings.Default.RemoteStartButtonY = StartConfig.RemoteButton.Y;
                Properties.Settings.Default.RemoteStopButtonX = StopConfig.RemoteButton.X;
                Properties.Settings.Default.RemoteStopButtonY = StopConfig.RemoteButton.Y;
                Properties.Settings.Default.ServerURI = ServerURI;
                Properties.Settings.Default.Save();
                AddMessage("Configuration saved!");
            }
            catch (Exception ex)
            {
                AddException(ex);
            }
        }

        public void SimulClick(SimulClickConfig config)
        {
            try
            {
                bool result = MouseService.Connect();
                if (!result)
                {
                    AddMessage("Cannot communicate with the server.");
                    return;
                }
                AddMessage($"Clicking at ({config.LocalButton.X}, {config.LocalButton.Y}) on local computer");
                result = MouseClickHelper.Click(config.LocalButton.Button, config.LocalButton.X, config.LocalButton.Y);
                if (!result)
                {
                    AddMessage("Failed to click on local computer");
                    return;
                }
                AddMessage($"Clicking at ({config.RemoteButton.X}, {config.RemoteButton.Y}) on remote computer");
                result = MouseService.Click(config.RemoteButton.Button, config.RemoteButton.X, config.RemoteButton.Y);
                if (!result)
                {
                    AddMessage("Failed to click on remote computer");
                    return;
                }
                AddMessage("Success!");
            }
            catch (Exception ex)
            {
                AddException(ex);
                MouseService.Abort();
                MouseService = new MouseService.MouseServiceClient();
            }
        }

        public void AddMessage(string message)
        {
            if (!string.IsNullOrEmpty(Messages))
            {
                Messages += Environment.NewLine;
            }
            Messages += DateTime.Now.ToString("yyyy-MM-dd H:mm:ss.fff: ") + message;
        }

        public void AddException(Exception ex)
        {
            AddMessage($"An exception occurred: {ex.Message}");
        }
    }
}
