﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulClickClient.ViewModels
{
    public class ButtonInfo: NotificationObject
    {
        private int m_Button = 0;
        private int m_X = 0;
        private int m_Y = 0;

        public int Button
        {
            get => m_Button;
            set => SetField(ref m_Button, value);
        }

        public int X
        {
            get => m_X;
            set => SetField(ref m_X, value);
        }

        public int Y
        {
            get => m_Y;
            set => SetField(ref m_Y, value);
        }
    }

    /// <summary>
    /// Configuration
    /// </summary>
    public class SimulClickConfig: NotificationObject
    {
        private ButtonInfo m_LocalButton = new ButtonInfo();
        private ButtonInfo m_RemoteButton = new ButtonInfo();
        
        public ButtonInfo LocalButton
        {
            get => m_LocalButton;
            set => SetField(ref m_LocalButton, value);
        }

        public ButtonInfo RemoteButton
        {
            get => m_RemoteButton;
            set => SetField(ref m_RemoteButton, value);
        }
    }
}
