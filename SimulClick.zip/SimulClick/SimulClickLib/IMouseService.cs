﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SimulClickLib
{
    [ServiceContract]
    public interface IMouseService
    {
        /// <summary>
        /// Moves mouse pointer to the given position and clicks the specified mouse button.
        /// </summary>
        /// <param name="button">0: Left, 1: Right</param>
        /// <param name="x">x coordinate of the screen location to move the mouse pointer to prior to clicking.</param>
        /// <param name="y">y coordinate of the screen location to move the mouse pointer to prior to clicking.</param>
        /// <returns>A value indicating whether the operation is successful.</returns>
        [OperationContract]
        bool Click(int button, int x, int y);

        /// <summary>
        /// Tests the connection to the service.
        /// </summary>
        /// <returns>If service is up, always returns true.</returns>
        [OperationContract]
        bool Connect();
    }
}
