﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SimulClickLib
{
    public class MouseService : IMouseService
    {
        public bool Connect()
        {
            return true;
        }

        public bool Click(int button, int x, int y)
        {
            return MouseClickHelper.Click(button, x, y);
        }
    }
}
