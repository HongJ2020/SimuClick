﻿using Common;
using SimulClickLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimulClickApp.ViewModels
{
    /// <summary>
    /// View-model of the server interface.
    /// </summary>
    public class ServerViewModel: NotificationObject
    {
        string m_URI = Properties.Settings.Default.ServerURI;
        string m_Messages = "";
        bool m_ServerStarted = false;

        ServiceHost Host { get; set; }

        public string URI
        {
            get => m_URI;
            set => SetField(ref m_URI, value);
        }

        public string Messages
        {
            get => m_Messages;
            set => SetField(ref m_Messages, value);
        }

        public bool ServerStarted
        {
            get => m_ServerStarted;
            set
            {
                if (value != m_ServerStarted)
                {
                    m_ServerStarted = value;
                    StartServerCommand?.RaiseCanExecuteChanged();
                    StopServerCommand?.RaiseCanExecuteChanged();
                    RaisePropertyChanged();
                }
            }
        }

        public ICommand StartServerCommand { get; private set; }
        public ICommand StopServerCommand { get; private set; }


        public ServerViewModel()
        {
            StartServerCommand = new Command(o => StartServer(), o => !ServerStarted);
            StopServerCommand = new Command(o => StopServer(), o => ServerStarted);
        }

        public void StartServer()
        {
            try
            {
                Properties.Settings.Default.ServerURI = URI;
                Properties.Settings.Default.Save();
            }
            catch (Exception ex)
            {
                AddMessage($"An exception occurred: {ex.Message}");
            }

            // Step 1: Create a URI to serve as the base address.
            Uri baseAddress = new Uri(URI);

            // Step 2: Create a ServiceHost instance.
            Host = new ServiceHost(typeof(MouseService), baseAddress);

            try
            {
                AddMessage($"Starting server on {baseAddress}");
                // Step 3: Add a service endpoint.
                var b = new WSHttpBinding();
                b.Security.Mode = SecurityMode.None;
                Host.AddServiceEndpoint(typeof(IMouseService), b, "MouseService");

                // Step 4: Enable metadata exchange.
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                smb.HttpGetEnabled = true;
                Host.Description.Behaviors.Add(smb);

                // Step 5: Start the service.
                Host.Open();

                ServerStarted = true;

                AddMessage("Server started");
            }
            catch (CommunicationException ce)
            {
                AddMessage($"An exception occurred: {ce.Message}");
                Host.Abort();
            }
        }

        public void AddMessage(string message)
        {
            Messages += Environment.NewLine + DateTime.Now.ToString("yyyy-MM-dd H:mm:ss.fff ") + message;
        }

        public void StopServer()
        {
            if (Host != null)
            {
                try
                {
                    Host.Close();
                    ServerStarted = false;
                    AddMessage("Server stopped");
                }
                catch (Exception ex)
                {
                    AddMessage($"An exception occurred: {ex.Message}");
                }
            }
        }
    }
}
